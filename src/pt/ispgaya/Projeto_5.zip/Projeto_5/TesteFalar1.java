package pt.ispgaya.Projeto_5;

public class TesteFalar1 {
//
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Aluno aluno = new Aluno();
        Professor professor=new Professor();

        aluno.falar();
        professor.falar();


    }

}
