package pt.ispgaya.Projeto_6;

public class Calculadora {

    //Construtor
    public Calculadora() {
    }

    //Métodos
    public double Dividir(double x, double y, double z) {
        return x / y / z;
    }

    public double Subtrair(double x, double y, double z) {
        return x - y - z;
    }

    public double Somar(double x, double y, double z) {
        return x + y + z;
    }

    public double Multiplicar(double x, double y, double z) {
        return x * y * z;
    }

    public double Dividir(double x, double y) {
        return x / y;
    }

    public double Subtrair(double x, double y) {
        return x - y;
    }

    public double Somar(double x, double y) {
        return x + y;
    }

    public double Multiplicar(double x, double y) {
        return x * y;
    }
}
