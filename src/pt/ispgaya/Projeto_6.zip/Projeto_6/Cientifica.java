package pt.ispgaya.Projeto_6;

public class Cientifica extends Calculadora {
    public Cientifica() {

    }

    public double Pot(double x, int y) {
        return Math.pow(x, y);
    }

    public double Raiz(double x) {
        return Math.sqrt(x);
    }
}
